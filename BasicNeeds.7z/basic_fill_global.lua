-- SPDX-License-Identifier: GPL-3.0-or-later
-- -----------------------------------------------------------------------------
-- scripts/BasicNeeds/global.lua
-- 2023 -- Antti Joutsi <antti.joutsi@gmail.com> (original author)
-- 2025 -- Modified by DreaddyMck for Devilish Needs
--
-- Because access to data and item creation happens in the GLOBAL scope, we need
-- to pass events back and forth, otherwise we'd end up loading and transforming
-- data multiple times.
-- -----------------------------------------------------------------------------

local Data = require("openmw.interfaces").BasicNeedsData

-- basic_fill
-- check: if item is not fillable run patch
local function devilishNeedsPatchCheck(eventData)
   if (not Data.getFilledVariantId(eventData.item)) then
      print("[basic_fill_global.lua] devilishNeedsPatchCheck: Item not fillable, Applying PATCH: ", eventData.item)
      Data.ApplyPatch()
   end
end

return {
   eventHandlers = {
      devilishNeedsPatchCheck = devilishNeedsPatchCheck,
   }
}