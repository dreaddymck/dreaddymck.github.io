-- SPDX-License-Identifier: GPL-3.0-or-later
-- -----------------------------------------------------------------------------
-- scripts/BasicNeeds/basic_fill.lua
-- 2025 -- DreaddyMck - restores basic needs fill container when standing or swimming in water
-- -----------------------------------------------------------------------------
local types    = require('openmw.types')
local core     = require("openmw.core")
local input    = require("openmw.input")
local self     = require("openmw.self")
local Actor    = types.Actor
local ACTION   = require("openmw.input").ACTION

local settings = require("scripts.BasicNeeds.settings")
local State    = require("scripts.BasicNeeds.state")
local L        = core.l10n("BasicNeeds")

local ui       = require("openmw.ui")

local footwaterleft = false
local footwaterright = false
local waistdeep = false
local swimming = false

-- -----------------------------------------------------------------------------
-- Initialization
-- -----------------------------------------------------------------------------
local ITEM     = 'misc_com_bottle_01'
local IS_WATER = false

local state    = State.new({
    previousTime   = core.getGameTime(),
    previousCell   = self.object.cell,
    wellRestedTime = nil,
    thirst         = 0,
    hunger         = 0,
    exhaustion     = 0,
    coldness       = 0,
    wet            = 0,
}, settings.getValues(settings.group))

local function isPlayerCrouchinginWater()
    return input.getBooleanActionValue('Sneak') and IS_WATER -- Returns true if sneak key is held
end

local function BasicFill(eventData)
    if core.isWorldPaused() then return end
    -- Using Hold Sneak + Activate as hotkey combination
    if (eventData.thirst and eventData.action == ACTION.Activate and isPlayerCrouchinginWater()) then
        core.sendGlobalEvent("PlayerFillContainer", { player = self })
    end
end

local function playerFilledContainer(eventData)
    if eventData.containerName then
        ui.showMessage(L("filledContainer", { item = eventData.containerName }))
    else
        ui.showMessage(L("noContainers"))
        Actor.spells(self):add('detd_fillwaterbottlesfail')
    end
end

-- -----------------------------------------------------------------------------
-- Engine/event handlers
-- -----------------------------------------------------------------------------
local function onFrame()
    footwaterleft = core.sound.isSoundPlaying("footwaterleft", self.object);
    footwaterright = core.sound.isSoundPlaying("footwaterright", self.object);
    if self.cell ~= nil then
        waistdeep = self.cell.isExterior and self.position.z < 10
    end
    swimming = Actor.isSwimming(self)
    IS_WATER = footwaterleft or footwaterright or waistdeep or swimming
    -- print("[player.lua] all!", footwaterleft, footwaterright, waistdeep, swimming, self.position.z, self.cell.waterLevel, self.cell.isExterior)
    -- if IS_WATER then
    --     ui.showMessage("Water is available")
    -- end
end

local function onLoad() -- check if a common item is fillable if not run patches
    core.sendGlobalEvent("devilishNeedsPatchCheck", { item = ITEM })
end

local function onInputAction(action)
    if core.isWorldPaused() then return end
    -- basic_fill
    -- restores basic needs fill container when standing or swimming in water.
    -- Hold Crouch + Tap Activate
    self:sendEvent("BasicFill", {
        action = action,
        thirst = state.thirst:isEnabled()
    })
end

-- -----------------------------------------------------------------------------
-- Return script interface
-- -----------------------------------------------------------------------------
return {
    engineHandlers = {
        onFrame = onFrame,
        onLoad = onLoad,
        onInputAction = onInputAction,
    },
    eventHandlers = {
        BasicFill = BasicFill,
        PlayerFilledContainer = playerFilledContainer,
    },
}
