-- SPDX-License-Identifier: GPL-3.0-or-later
-- -----------------------------------------------------------------------------
-- scripts/BasicNeeds/basic_fill.lua
-- 2025 -- DreaddyMck - restores basic needs fill container when standing or swimming in water
-- -----------------------------------------------------------------------------
local types  = require('openmw.types')
local core   = require("openmw.core")
local input  = require("openmw.input")
local self   = require("openmw.self")
local Actor  = types.Actor
local ACTION = require("openmw.input").ACTION
local L      = core.l10n("BasicNeeds")
local ui     = require("openmw.ui")



-- -----------------------------------------------------------------------------
-- Initialization
-- -----------------------------------------------------------------------------
local ITEM           = 'misc_com_bottle_01'
local IS_WATER       = false
local footwaterleft  = false
local footwaterright = false
local waistdeep      = false
local swimming       = false

local function isPlayerCrouchinginWater()
    return input.getBooleanActionValue('Sneak') and IS_WATER -- Returns true if sneak key is held
end

local function BasicFill(eventData)
    if core.isWorldPaused() then return end
    -- Using Hold Sneak + Activate as hotkey combination
    if (eventData.thirst and eventData.action == ACTION.Activate and isPlayerCrouchinginWater()) then
        core.sendGlobalEvent("PlayerFillContainer", { player = self })
    end
end

local function devilishNeedsPatch() -- check if a common item is fillable if not run patches
    core.sendGlobalEvent("devilishNeedsPatchCheck", { item = ITEM })
end

-- -----------------------------------------------------------------------------
-- Engine/event handlers
-- -----------------------------------------------------------------------------
local function onFrame()
    footwaterleft = core.sound.isSoundPlaying("footwaterleft", self.object);
    footwaterright = core.sound.isSoundPlaying("footwaterright", self.object);
    if self.cell ~= nil then
        waistdeep = self.cell.isExterior and self.position.z < 10
    end
    swimming = Actor.isSwimming(self)
    IS_WATER = footwaterleft or footwaterright or waistdeep or swimming
    -- print("[player.lua] all!", footwaterleft, footwaterright, waistdeep, swimming, self.position.z, self.cell.waterLevel, self.cell.isExterior)
    -- if IS_WATER then
    --     ui.showMessage("Water is available")
    -- end
end

-- -----------------------------------------------------------------------------
-- Return script interface
-- -----------------------------------------------------------------------------
return {
    engineHandlers = {
        onFrame = onFrame,
    },
    eventHandlers = {
        BasicFill = BasicFill,
        devilishNeedsPatch = devilishNeedsPatch,
    },
}
