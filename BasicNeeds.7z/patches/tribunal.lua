-- -----------------------------------------------------------------------------
-- Item data for Tribunal expansion
-- -----------------------------------------------------------------------------
return {
   consumables = {
      ["ingred_durzog_meat_01"]   = { 0, -1000, 0 },
      ["ingred_scrib_cabbage_01"] = { 0, -50, 0 },
      ["ingred_sweetpulp_01"]     = { 0, -50, 0 },
   },
   containers = {},

      toxicsubstances = {						
	-- Ingrendient								Identifier, Disease Chance
	-- debug entry: ["ingred_scuttle_01"] 			     = {"raw meat", 100 },
	  ["ingred_durzog_meat_01"] 			     = {"raw meat", 100 },
	},
}
